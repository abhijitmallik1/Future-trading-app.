# Future Trading — private chat + voice call (Flutter + Firebase + WebRTC)

A minimal starter you can run on Android/iOS. Features:
- Email/password registration & login (Firebase Auth)
- 1-to-1 chat (Cloud Firestore)
- Push-to-talk style voice calls via WebRTC (flutter_webrtc) with Firestore as signaling
- Simple, clean UI for two users (you and your girlfriend ❤️)

## Quick start

1) **Install tools**
- Flutter SDK (stable), Android Studio/Xcode
- A Google Firebase project

2) **Create a Flutter app scaffold**
```bash
flutter create future_trading
cd future_trading
```

3) **Copy these files into your project**
- Replace your `/lib` and `pubspec.yaml` with the ones from this zip.
- Add `firestore.rules` to your Firebase console later.

4) **Add Firebase**
- In Firebase console: add Android + iOS apps to the project.
- Download `google-services.json` (Android) into `android/app/`.
- Download `GoogleService-Info.plist` (iOS) into `ios/Runner/`.
- In `android/build.gradle` + `android/app/build.gradle` ensure Google services plugin is applied.
- In iOS, add Firebase initialization to `AppDelegate` if prompted.

5) **Enable products**
- Firebase Auth: enable Email/Password.
- Cloud Firestore: create database in test mode (then apply rules below).
- (Optional) FCM for notifications later.

6) **Run**
```bash
flutter pub get
flutter run
```

### Firestore structure (auto-created)
- `users/{uid}`: { displayName, email }
- `chats/{chatId}/messages/{messageId}`: { text, senderId, createdAt }
- `calls/{callId}`: { from, to, offer, answer }
  - `calls/{callId}/offerCandidates`
  - `calls/{callId}/answerCandidates`

### Security rules (paste into Firestore rules)
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isAuthed() { return request.auth != null; }
    match /users/{uid} {
      allow read: if isAuthed();
      allow write: if isAuthed() && request.auth.uid == uid;
    }
    match /chats/{chatId} {
      allow read, write: if isAuthed();
      match /messages/{doc} {
        allow read, write: if isAuthed();
      }
    }
    match /calls/{callId} {
      allow read, write: if isAuthed();
      match /{sub=**} {
        allow read, write: if isAuthed();
      }
    }
  }
}
```

### Notes
- This is a **starter** — good for private use. For production, add user search, block/report, message encryption, call timeouts, background handling, etc.
- Rename the app by changing `title` and Android/iOS bundle names as needed.
