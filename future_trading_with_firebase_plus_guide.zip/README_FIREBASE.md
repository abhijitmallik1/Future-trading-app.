

---

# Firebase Config Added ✅

- Your `google-services.json` (Android) is included here → move it to `/android/app/google-services.json`
- Your `GoogleService-Info.plist` (iOS) is included here → move it to `/ios/Runner/GoogleService-Info.plist`

## Next step to build APK (Android)
```bash
flutter pub get
flutter build apk --release
```
APK will be at:
`build/app/outputs/flutter-apk/app-release.apk`

Send this APK to your girlfriend ❤️

## Next step for iOS
1. Open project in Xcode (`ios/Runner.xcworkspace`).
2. Ensure `GoogleService-Info.plist` is in `Runner` target.
3. Run on your iPhone (Apple Developer account needed for distribution).
