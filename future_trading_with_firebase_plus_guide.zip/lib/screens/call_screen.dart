import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class CallScreen extends StatefulWidget {
  const CallScreen({super.key});

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  final _peerEmail = TextEditingController();
  final _localRenderer = RTCVideoRenderer();
  final _remoteRenderer = RTCVideoRenderer();
  RTCPeerConnection? _pc;
  MediaStream? _localStream;
  DocumentReference<Map<String, dynamic>>? _callDoc;
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _localRenderer.initialize();
    _remoteRenderer.initialize();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _pc?.close();
    _localStream?.dispose();
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    super.dispose();
  }

  Future<void> _startCall(String myId, String toEmail) async {
    final db = FirebaseFirestore.instance;
    final config = <String, dynamic>{
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'}
      ]
    };
    _pc = await createPeerConnection(config);
    _localStream = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': false});
    _localRenderer.srcObject = _localStream;
    _localStream!.getTracks().forEach((t) => _pc!.addTrack(t, _localStream!));
    _pc!.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        _remoteRenderer.srcObject = event.streams[0];
      }
    };

    _callDoc = db.collection('calls').doc();
    final offerCandidates = _callDoc!.collection('offerCandidates');
    final answerCandidates = _callDoc!.collection('answerCandidates');

    _pc!.onIceCandidate = (c) async {
      if (c.candidate != null) {
        await offerCandidates.add({'candidate': c.candidate, 'sdpMid': c.sdpMid, 'sdpMLineIndex': c.sdpMLineIndex});
      }
    };

    final offer = await _pc!.createOffer();
    await _pc!.setLocalDescription(offer);

    await _callDoc!.set({'from': myId, 'toEmail': toEmail, 'offer': offer.sdp});

    _sub = _callDoc!.snapshots().listen((snap) async {
      final data = snap.data();
      if (data == null) return;
      final answerSdp = data['answer'];
      if (answerSdp != null && _pc!.remoteDescription == null) {
        await _pc!.setRemoteDescription(RTCSessionDescription(answerSdp, 'answer'));
      }
    });

    answerCandidates.snapshots().listen((q) async {
      for (var doc in q.docChanges) {
        final d = doc.doc.data();
        if (d == null) continue;
        await _pc!.addCandidate(RTCIceCandidate(d['candidate'], d['sdpMid'], d['sdpMLineIndex']));
      }
    });
  }

  Future<void> _answerCall(String myId, String callId) async {
    final db = FirebaseFirestore.instance;
    _callDoc = db.collection('calls').doc(callId);
    final data = (await _callDoc!.get()).data();
    if (data == null) return;

    final config = <String, dynamic>{
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'}
      ]
    };
    _pc = await createPeerConnection(config);
    _localStream = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': false});
    _localRenderer.srcObject = _localStream;
    _localStream!.getTracks().forEach((t) => _pc!.addTrack(t, _localStream!));
    _pc!.onTrack = (event) {
      if (event.streams.isNotEmpty) {
        _remoteRenderer.srcObject = event.streams[0];
      }
    };

    final offerCandidates = _callDoc!.collection('offerCandidates');
    final answerCandidates = _callDoc!.collection('answerCandidates');

    _pc!.onIceCandidate = (c) async {
      if (c.candidate != null) {
        await answerCandidates.add({'candidate': c.candidate, 'sdpMid': c.sdpMid, 'sdpMLineIndex': c.sdpMLineIndex});
      }
    };

    await _pc!.setRemoteDescription(RTCSessionDescription(data['offer'], 'offer'));
    final answer = await _pc!.createAnswer();
    await _pc!.setLocalDescription(answer);
    await _callDoc!.update({'answer': answer.sdp});

    offerCandidates.snapshots().listen((q) async {
      for (var doc in q.docChanges) {
        final d = doc.doc.data();
        if (d == null) continue;
        await _pc!.addCandidate(RTCIceCandidate(d['candidate'], d['sdpMid'], d['sdpMLineIndex']));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final me = auth.user!;

    return Scaffold(
      appBar: AppBar(title: const Text('Future Trading – Voice Call')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _peerEmail, decoration: const InputDecoration(labelText: 'Partner email')),
            const SizedBox(height: 8),
            Row(
              children: [
                FilledButton(
                  onPressed: () => _startCall(me.uid, _peerEmail.text.trim()),
                  child: const Text('Start call'),
                ),
                const SizedBox(width: 8),
                FilledButton.tonal(
                  onPressed: () async {
                    // Enter received callId to answer
                    final controller = TextEditingController();
                    await showDialog(context: context, builder: (_) {
                      return AlertDialog(
                        title: const Text('Enter Call ID'),
                        content: TextField(controller: controller),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                          TextButton(onPressed: () async {
                            await _answerCall(me.uid, controller.text.trim());
                            if (context.mounted) Navigator.pop(context);
                          }, child: const Text('Answer')),
                        ],
                      );
                    });
                  },
                  child: const Text('Answer call'),
                )
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Column(
                children: [
                  Expanded(child: RTCVideoView(_localRenderer, mirror: true)),
                  const SizedBox(height: 8),
                  Expanded(child: RTCVideoView(_remoteRenderer)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                FilledButton(
                  onPressed: () async {
                    await _pc?.close();
                    await _localStream?.dispose();
                    setState(() {
                      _pc = null;
                      _localStream = null;
                    });
                  },
                  child: const Text('Hang up'),
                ),
                const SizedBox(width: 8),
                Builder(builder: (context) {
                  return FilledButton.tonal(
                    onPressed: () async {
                      if (_callDoc != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Share Call ID: ${_callDoc!.id}')),
                        );
                      }
                    },
                    child: const Text('Share Call ID'),
                  );
                }),
              ],
            )
          ],
        ),
      ),
    );
  }
}
