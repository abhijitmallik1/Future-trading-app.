import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  String? _peerEmail;
  String? _error;

  String chatIdFor(String a, String b) {
    final list = [a, b]..sort();
    return '${list[0]}_${list[1]}';
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final me = auth.user!;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Future Trading – Chat'),
        actions: [
          IconButton(onPressed: () => Navigator.pushNamed(context, '/call'), icon: const Icon(Icons.call)),
          IconButton(onPressed: () => auth.logout(), icon: const Icon(Icons.logout)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                      labelText: 'Your partner’s email',
                    ),
                    onChanged: (v) => setState(() => _peerEmail = v.trim()),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () => setState(() {}),
                  child: const Text('Set'),
                )
              ],
            ),
          ),
          if (_peerEmail == null || _peerEmail!.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12.0),
              child: Text('Tip: enter your girlfriend’s email above (the one she uses to sign in).'),
            ),
          if (_error != null) Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(_error!, style: const TextStyle(color: Colors.red)),
          ),
          const Divider(height: 1),
          Expanded(
            child: _peerEmail == null || _peerEmail!.isEmpty
                ? const Center(child: Text('No conversation selected'))
                : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: FirebaseFirestore.instance
                        .collection('chats')
                        .doc(chatIdFor(me.email!, _peerEmail!))
                        .collection('messages')
                        .orderBy('createdAt', descending: true)
                        .snapshots(),
                    builder: (context, snap) {
                      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                      final docs = snap.data!.docs;
                      return ListView.builder(
                        reverse: true,
                        itemCount: docs.length,
                        itemBuilder: (_, i) {
                          final m = docs[i].data();
                          final isMe = m['senderId'] == me.uid;
                          return Align(
                            alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(),
                              ),
                              child: Text(m['text'] ?? ''),
                            ),
                          );
                        },
                      );
                    },
                  ),
          ),
          SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _text,
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 12),
                      hintText: 'Message…',
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () async {
                    if ((_peerEmail ?? '').isEmpty || _text.text.trim().isEmpty) return;
                    try {
                      final chatId = chatIdFor(me.email!, _peerEmail!);
                      await FirebaseFirestore.instance
                          .collection('chats')
                          .doc(chatId)
                          .collection('messages')
                          .add({
                        'text': _text.text.trim(),
                        'senderId': me.uid,
                        'createdAt': FieldValue.serverTimestamp(),
                      });
                      _text.clear();
                    } catch (e) {
                      setState(() => _error = e.toString());
                    }
                  },
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
