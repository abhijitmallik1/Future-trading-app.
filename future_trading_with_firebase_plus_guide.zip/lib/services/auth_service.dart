import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

enum AuthState { loading, authed, unauthed }

class AuthService extends ChangeNotifier {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;
  User? user;
  AuthState state = AuthState.loading;

  AuthService() {
    _auth.authStateChanges().listen((u) async {
      user = u;
      state = u == null ? AuthState.unauthed : AuthState.authed;
      if (u != null) {
        await _db.collection('users').doc(u.uid).set({
          'email': u.email,
          'displayName': u.displayName ?? u.email?.split('@').first,
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
      notifyListeners();
    });
  }

  Future<void> register(String email, String password) async {
    await _auth.createUserWithEmailAndPassword(email: email, password: password);
  }

  Future<void> login(String email, String password) async {
    await _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<void> logout() async {
    await _auth.signOut();
  }
}
